/* ============================================================
   MAISON N°7 — The Composition Table
   Wardrobe data

   Mirrors assets/data/wardrobe.json, inlined so the app works when
   opened directly as a file (fetch() of local JSON is blocked by
   file:// CORS rules). Switch to fetching the JSON if you serve
   this from a real web server.

   Every garment carries a `fit` block measured directly from its
   own source PNG: contentHeightPx / contentWidthPx is the garment's
   real pixel size within its canvasPx square (the rest of that
   square is transparent margin). All source photos share the same
   canvas size and the same real-world shoot scale, so content-
   height in pixels is directly comparable across garments.
   renderGarment() uses that to normalize scale, same as before —
   what changed in this pass is that the two garments no longer
   pretend to be one worn body. They are laid flat, side by side,
   each independently true to its own photographed proportions,
   which is what actually fixed "the proportions are off": there
   was never a shared body scale to normalize to in the first place.
   ============================================================ */
const WARDROBE = {
  jackets: [
    { id: 'jacket-01-bomber-black',     label: 'Bomber',            color: 'Black',    file: 'assets/images/jackets/jacket-01-bomber-black.png',     fit: { contentHeightPx: 1075, contentWidthPx: 990,  canvasPx: 1254 } },
    { id: 'jacket-02-puffer-stone',     label: 'Puffer',            color: 'Stone',    file: 'assets/images/jackets/jacket-02-puffer-stone.png',     fit: { contentHeightPx: 1024, contentWidthPx: 1158, canvasPx: 1254 } },
    { id: 'jacket-03-utility-charcoal', label: 'Utility Overshirt', color: 'Charcoal', file: 'assets/images/jackets/jacket-03-utility-charcoal.png', fit: { contentHeightPx: 1059, contentWidthPx: 1092, canvasPx: 1254 } },
  ],
  pants: [
    { id: 'pants-01-tapered-charcoal', label: 'Tapered',  color: 'Charcoal', file: 'assets/images/pants/pants-01-tapered-charcoal.png', fit: { contentHeightPx: 1180, contentWidthPx: 488, canvasPx: 1254 } },
    { id: 'pants-02-cargo-khaki',      label: 'Cargo',    color: 'Khaki',    file: 'assets/images/pants/pants-02-cargo-khaki.png',      fit: { contentHeightPx: 1184, contentWidthPx: 626, canvasPx: 1254 } },
    { id: 'pants-03-straight-black',   label: 'Straight', color: 'Black',    file: 'assets/images/pants/pants-03-straight-black.png',   fit: { contentHeightPx: 1169, contentWidthPx: 440, canvasPx: 1254 } },
  ],
};

/* Tint presets applied on top of whichever piece is equipped, via
   CSS filter (a duotone-style grayscale + sepia + hue-rotate combo).
   Unchanged from the source data — every swatch hex is the actual
   simulated output of its filter against the real garment PNGs. */
const TINTS = [
  { name: 'Natural',  filter: 'none',                                                                  swatch: '#a4a4a4' },
  { name: 'Jet',       filter: 'grayscale(1) brightness(0.24) contrast(1.05)',                          swatch: '#232323' },
  { name: 'Charcoal', filter: 'grayscale(1) brightness(0.5) sepia(0.12)',                                swatch: '#555451' },
  { name: 'Graphite', filter: 'grayscale(1) brightness(0.7)',                                            swatch: '#737373' },
  { name: 'Stone',    filter: 'grayscale(0.8) sepia(0.22) brightness(1.02) saturate(0.7)',               swatch: '#b3afa8' },
  { name: 'Bone',     filter: 'grayscale(1) sepia(0.35) brightness(1.22) saturate(0.55)',                swatch: '#dcd7cc' },
  { name: 'Espresso', filter: 'grayscale(1) sepia(1) hue-rotate(-10deg) saturate(1.15) brightness(0.42)', swatch: '#625140' },
  { name: 'Camel',    filter: 'grayscale(1) sepia(1) hue-rotate(-5deg) saturate(0.9) brightness(0.92)',   swatch: '#cdb593' },
  { name: 'Burgundy', filter: 'grayscale(1) sepia(1) hue-rotate(-48deg) saturate(2) brightness(0.44)',    swatch: '#704c4b' },
  { name: 'Rust',     filter: 'grayscale(1) sepia(1) hue-rotate(-25deg) saturate(1.5) brightness(0.62)',  swatch: '#9e745e' },
  { name: 'Forest',   filter: 'grayscale(1) sepia(1) hue-rotate(60deg) saturate(1.15) brightness(0.55)',  swatch: '#5c7653' },
  { name: 'Olive',    filter: 'grayscale(1) sepia(1) hue-rotate(30deg) saturate(0.9) brightness(0.72)',   swatch: '#8d936f' },
];

const CATEGORIES = ['jackets', 'pants'];
const STORAGE_KEY = 'maison-n7-fitting-room-v2';

/* Reference unit used to normalize relative scale across garments.

   Each <img> is laid out with object-fit: contain inside its bay, so
   the browser already fits each PNG's full square canvas (not just
   its visible garment content) into the same box. Two garments with
   the same canvasPx therefore render at the same on-screen size by
   default even though one has much more transparent margin than the
   other — a slim trouser on a mostly-empty square reads far smaller
   than a jacket that fills most of its square.

   To correct for that, normalize by contentHeightPx/canvasPx — the
   fraction of the square each garment's real content actually
   occupies — relative to jacket-01 as the "1.0" reference. That
   fraction, not the raw pixel height, is what's comparable once
   object-fit has already equalized the canvases themselves. */
const REFERENCE_FILL = WARDROBE.jackets[0].fit.contentHeightPx / WARDROBE.jackets[0].fit.canvasPx;

const FIT_CONTROLS = [
  { key: 'scale',  label: 'Scale',  min: 60,   max: 160,  step: 1, unit: '%',  default: 100 },
  { key: 'width',  label: 'Width',  min: 70,   max: 150,  step: 1, unit: '%',  default: 100 },
  { key: 'height', label: 'Height', min: 70,   max: 150,  step: 1, unit: '%',  default: 100 },
  { key: 'x',      label: 'Move X', min: -40,  max: 40,   step: 1, unit: '%',  default: 0 },
  { key: 'y',      label: 'Move Y', min: -40,  max: 40,   step: 1, unit: '%',  default: 0 },
];

function defaultFit() {
  const fit = {};
  FIT_CONTROLS.forEach((c) => { fit[c.key] = c.default; });
  return fit;
}

/* ============================================================
   Sizing
   A garment's "size" is a step on a real run (XS→XXL), each one
   a fixed percentage larger than the last on both axes — roughly
   how a size run actually scales a pattern, not just a cosmetic
   label. Picking a size sets the baseline the manual Fit sliders
   above (scale/width/height) then multiply on top of, so "L, then
   nudged 5% wider" is still expressible without the two systems
   fighting each other. Index 2 (M) is the neutral, 1.0x step.
   ============================================================ */
const SIZES = [
  { name: 'XS',  step: 0.88 },
  { name: 'S',   step: 0.94 },
  { name: 'M',   step: 1.00 },
  { name: 'L',   step: 1.07 },
  { name: 'XL',  step: 1.14 },
  { name: 'XXL', step: 1.22 },
];
const DEFAULT_SIZE = 'M';

function findSize(name) {
  return SIZES.find((s) => s.name === name) || SIZES[2];
}

function getSize(category, pieceId) {
  return state[category].sizeByPiece[pieceId] || DEFAULT_SIZE;
}

function setSize(category, pieceId, sizeName) {
  state[category].sizeByPiece[pieceId] = sizeName;
}

/* How far apart two sizes are on the run, e.g. M→L is 1 step,
   XS→XXL is 5 steps. Used to phrase the compatibility note. */
function sizeGapSteps(a, b) {
  return SIZES.findIndex((s) => s.name === a) - SIZES.findIndex((s) => s.name === b);
}

/* ============================================================
   State
   ============================================================ */
function defaultState() {
  return {
    jackets: { pieceId: WARDROBE.jackets[0].id, tint: 'Natural', fitByPiece: {}, sizeByPiece: {} },
    pants:   { pieceId: WARDROBE.pants[1].id,   tint: 'Natural', fitByPiece: {}, sizeByPiece: {} },
    lookCount: 1,
    worn: false,
  };
}

function findPiece(category, id) {
  return WARDROBE[category].find((p) => p.id === id);
}

function findTint(name) {
  return TINTS.find((t) => t.name === name) || TINTS[0];
}

function getFit(category, pieceId) {
  const entry = state[category].fitByPiece[pieceId];
  return entry ? { ...defaultFit(), ...entry } : defaultFit();
}

function setFit(category, pieceId, key, value) {
  if (!state[category].fitByPiece[pieceId]) {
    state[category].fitByPiece[pieceId] = defaultFit();
  }
  state[category].fitByPiece[pieceId][key] = value;
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    for (const category of CATEGORIES) {
      const entry = parsed[category];
      if (!entry || !findPiece(category, entry.pieceId)) return defaultState();
      if (!entry.fitByPiece) entry.fitByPiece = {};
      if (!entry.sizeByPiece) entry.sizeByPiece = {};
    }
    if (typeof parsed.lookCount !== 'number') parsed.lookCount = 1;
    if (typeof parsed.worn !== 'boolean') parsed.worn = false;
    return parsed;
  } catch (err) {
    return defaultState();
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    // Storage can fail in private browsing or when quota is full —
    // the app still works, it just won't remember the look on reload.
  }
}

let state = loadState();
let activeCategory = 'jackets';

/* ============================================================
   DOM references
   ============================================================ */
const layerEls = {
  jackets: document.getElementById('layer-jackets'),
  pants:   document.getElementById('layer-pants'),
};
const tiltEls = {
  jackets: document.getElementById('tiltJacket'),
  pants:   document.getElementById('tiltPants'),
};
const shadowEls = {
  jackets: document.getElementById('shadowJacket'),
  pants:   document.getElementById('shadowPants'),
};
const tagEls = {
  jackets: document.getElementById('tagJacket'),
  pants:   document.getElementById('tagPants'),
};
const captionEl = document.getElementById('caption');
const captionInlineEl = document.getElementById('captionInline');
const lookNumberEl = document.getElementById('lookNumber');
const sizeMatchEl = document.getElementById('sizeMatch');

/* ============================================================
   Rendering
   ============================================================ */
function renderGarment(category, { animate = false } = {}) {
  const { pieceId, tint } = state[category];
  const piece = findPiece(category, pieceId);
  const img = layerEls[category];
  const fit = getFit(category, pieceId);
  const sizeStep = findSize(getSize(category, pieceId)).step;

  img.src = piece.file;
  img.alt = `${piece.label}, ${piece.color.toLowerCase()}`;

  const tintDef = findTint(tint);
  // The jacket's resting-on-the-table drop-shadow is wide and soft on
  // purpose for the flat lay. Once it's stacked over the trouser in
  // worn mode, that same shadow bleeds onto the fabric underneath it
  // and reads as a stain, so it's tightened up for that state only.
  const isWornJacket = category === 'jackets' && state.worn;
  const dropShadow = isWornJacket
    ? 'drop-shadow(0 1px 1px rgba(0,0,0,0.22)) drop-shadow(0 6px 10px rgba(0,0,0,0.3))'
    : 'drop-shadow(0 2px 1px rgba(0,0,0,0.25)) drop-shadow(0 18px 30px rgba(0,0,0,0.45))';
  img.style.filter =
    (tintDef.filter === 'none' ? '' : tintDef.filter + ' ') + dropShadow;

  // Normalize so garments with very different amounts of transparent
  // PNG margin read at their true relative size to one another (see
  // REFERENCE_FILL above for why this uses the content/canvas ratio
  // rather than raw content-height once object-fit is in play).
  const fillRatio = piece.fit.contentHeightPx / piece.fit.canvasPx;
  const normalize = fillRatio / REFERENCE_FILL;

  // Size sets the baseline; the manual Fit sliders multiply on top
  // of that baseline rather than replacing it, so "L, nudged wider"
  // and "M, nudged narrower" can both be expressed with one slider.
  const scaleX = normalize * sizeStep * (fit.scale / 100) * (fit.width / 100);
  const scaleY = normalize * sizeStep * (fit.scale / 100) * (fit.height / 100);

  img.style.setProperty('--fit-scale-x', scaleX);
  img.style.setProperty('--fit-scale-y', scaleY);
  // Also exposed as custom properties (not just read from the plain
  // inline transform below) so the garment-settle keyframes can
  // include the same x/y offset at every step of the animation —
  // otherwise the animation's own translate values would silently
  // override fit.x/fit.y for the animation's duration, and the
  // garment would jump to centered, then jump again to its actual
  // dragged/offset position the instant the animation ends and the
  // browser reverts to reading this inline transform.
  img.style.setProperty('--fit-x', `${fit.x}%`);
  img.style.setProperty('--fit-y', `${fit.y}%`);
  img.style.transform =
    `translate(${fit.x}%, ${fit.y}%) scale(${scaleX}, ${scaleY})`;

  // Shadow width tracks scale, so a bigger garment casts a bigger
  // pool of shadow instead of a fixed prop underneath everything.
  const shadowEl = shadowEls[category];
  if (shadowEl) {
    const shadowScale = Math.max(0.55, Math.min(1.25, (scaleX + scaleY) / 2));
    shadowEl.style.width = `${62 * shadowScale}%`;
  }

  const tagEl = tagEls[category];
  if (tagEl) {
    tagEl.textContent = tint === 'Natural' ? piece.label : `${piece.label} · ${tint}`;
  }

  if (animate) {
    // Two elements animate together for the fold-in: the tilt
    // container clips itself open left-to-right (garment-fold-in)
    // while the <img> inside does the actual fabric settle motion
    // (garment-settle) — see the CSS for why this is split across
    // both rather than one element doing both jobs.
    const tiltEl = tiltEls[category];
    img.classList.remove('is-landing');
    if (tiltEl) tiltEl.classList.remove('is-landing');
    // eslint-disable-next-line no-unused-expressions
    void img.offsetWidth; // restart animation
    img.classList.add('is-landing');
    if (tiltEl) tiltEl.classList.add('is-landing');
  }
}

function applyAll(opts = {}) {
  CATEGORIES.forEach((category) => renderGarment(category, opts));
  updateCaption();
  updateActiveStates();
  renderFitControls(activeCategory);
  renderSizeControls(activeCategory);
  updateSizeMatch();
}

function updateCaption() {
  const parts = CATEGORIES.map((category) => {
    const piece = findPiece(category, state[category].pieceId);
    const tint = state[category].tint;
    const colorWord = tint === 'Natural' ? piece.color : tint;
    return `${colorWord.toLowerCase()} ${piece.label.toLowerCase()}`;
  });
  const joiner = state.worn ? ' worn over a ' : ' laid beside a ';
  const sentence = parts.join(joiner);
  captionEl.textContent = sentence.charAt(0).toUpperCase() + sentence.slice(1) + '.';

  const jacketTint = state.jackets.tint;
  const pantsTint = state.pants.tint;
  if (jacketTint === 'Natural' && pantsTint === 'Natural') {
    captionInlineEl.textContent = 'natural';
  } else {
    captionInlineEl.textContent = [jacketTint, pantsTint]
      .filter((t) => t !== 'Natural')
      .join(' · ')
      .toLowerCase();
  }
}

function updateActiveStates() {
  document.querySelectorAll('.piece-btn').forEach((btn) => {
    const isActive = state[btn.dataset.category].pieceId === btn.dataset.pieceId;
    btn.setAttribute('aria-pressed', String(isActive));
  });
  document.querySelectorAll('.tint-btn').forEach((btn) => {
    const isActive = state[btn.dataset.category].tint === btn.dataset.tint;
    btn.setAttribute('aria-pressed', String(isActive));
  });

  CATEGORIES.forEach((category) => {
    const section = document.querySelector(`.category[data-category="${category}"]`);
    const readout = section.querySelector('[data-role="tint-readout"]');
    if (readout) readout.textContent = state[category].tint;
  });
}

/* Builds a short human summary of how far the current fit strays
   from default. */
function describeFit(fit) {
  const bits = [];
  if (fit.scale !== 100) bits.push(`Scaled ${fit.scale}%`);
  if (fit.width !== 100 && fit.width !== fit.scale) bits.push(`Wide ${fit.width}%`);
  if (fit.height !== 100 && fit.height !== fit.scale) bits.push(`Tall ${fit.height}%`);
  if (fit.y < 0) bits.push('Raised');
  if (fit.y > 0) bits.push('Lowered');
  if (fit.x !== 0) bits.push(fit.x < 0 ? 'Shifted left' : 'Shifted right');
  return bits.length ? bits.join(' · ') : 'True to size';
}

/* ============================================================
   Size controls
   A row of size chips per category (XS…XXL). Picking one sets the
   baseline renderGarment() scales from; the Fit sliders below still
   fine-tune on top of it. A second readout compares the two
   categories' current sizes and explains, in plain language,
   whether the composition reads as a matched size or an
   intentionally oversized/cropped pairing.
   ============================================================ */
function renderSizeControls(category) {
  const section = document.querySelector(`.category[data-category="${category}"]`);
  const container = section.querySelector('[data-role="sizes"]');
  const readout = section.querySelector('[data-role="size-readout"]');
  const note = section.querySelector('[data-role="size-note"]');
  const { pieceId } = state[category];
  const current = getSize(category, pieceId);

  container.innerHTML = '';

  SIZES.forEach((size) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'size-btn';
    btn.textContent = size.name;
    btn.dataset.size = size.name;
    btn.setAttribute('aria-pressed', String(size.name === current));
    btn.setAttribute(
      'aria-label',
      `Size ${size.name} for the current ${category === 'jackets' ? 'jacket' : 'trouser'}`
    );

    btn.addEventListener('click', () => selectSize(category, size.name));
    container.appendChild(btn);
  });

  readout.textContent = current;
  note.textContent = sizeNoteFor(category);
}

/* One-line, single-garment framing of the chosen size — kept
   separate from the two-garment compatibility note below it. */
function sizeNoteFor(category) {
  const size = getSize(category, state[category].pieceId);
  if (size === DEFAULT_SIZE) return 'True to the sample size.';
  const gap = sizeGapSteps(size, DEFAULT_SIZE);
  return gap > 0
    ? `Sized up ${gap} step${gap > 1 ? 's' : ''} from sample.`
    : `Sized down ${Math.abs(gap)} step${Math.abs(gap) > 1 ? 's' : ''} from sample.`;
}

function selectSize(category, sizeName) {
  setSize(category, state[category].pieceId, sizeName);
  renderGarment(category, { animate: true });
  renderSizeControls(category);
  updateSizeMatch();
  saveState();
}

/* Compares the jacket's and the trouser's current sizes and writes
   a short, plain verdict under the table — the closest thing this
   app has to "will these two pieces actually look right together". */
function updateSizeMatch() {
  if (!sizeMatchEl) return;
  const jacketSize = getSize('jackets', state.jackets.pieceId);
  const pantsSize = getSize('pants', state.pants.pieceId);
  const gap = sizeGapSteps(jacketSize, pantsSize);
  const abs = Math.abs(gap);

  let text;
  let tone;
  if (abs === 0) {
    text = `Matched sizing · both pieces in ${jacketSize}.`;
    tone = 'match';
  } else if (abs === 1) {
    text = `Close enough · jacket ${jacketSize}, trouser ${pantsSize}. Reads as an intentional, relaxed pairing rather than a mismatch.`;
    tone = 'close';
  } else {
    const looseOne = gap > 0 ? 'jacket' : 'trouser';
    text = `Sizes are ${abs} steps apart · jacket ${jacketSize}, trouser ${pantsSize}. The ${looseOne} will read noticeably looser than the other piece.`;
    tone = 'gap';
  }
  sizeMatchEl.textContent = text;
  sizeMatchEl.dataset.tone = tone;
}

/* ============================================================
   Fit controls
   ============================================================ */
function renderFitControls(category) {
  const section = document.querySelector(`.category[data-category="${category}"]`);
  const container = section.querySelector('[data-role="fit-controls"]');
  const readout = section.querySelector('[data-role="fit-readout"]');
  const { pieceId } = state[category];
  const fit = getFit(category, pieceId);

  container.innerHTML = '';

  FIT_CONTROLS.forEach((control) => {
    const row = document.createElement('div');
    row.className = 'fit-control';

    const label = document.createElement('span');
    label.className = 'fit-control__label';
    label.textContent = control.label;

    const input = document.createElement('input');
    input.type = 'range';
    input.min = String(control.min);
    input.max = String(control.max);
    input.step = String(control.step);
    input.value = String(fit[control.key]);
    input.setAttribute('aria-label', `${control.label} for the current ${category === 'jackets' ? 'jacket' : 'trouser'}`);

    const value = document.createElement('span');
    value.className = 'fit-control__value';
    value.textContent = formatFitValue(control, fit[control.key]);

    input.addEventListener('input', () => {
      const num = Number(input.value);
      setFit(category, pieceId, control.key, num);
      value.textContent = formatFitValue(control, num);
      renderGarment(category);
      readout.textContent = describeFit(getFit(category, pieceId));
      saveState();
    });

    row.append(label, input, value);
    container.appendChild(row);
  });

  readout.textContent = describeFit(fit);
}

function formatFitValue(control, num) {
  if (control.key === 'x' || control.key === 'y') {
    return `${num > 0 ? '+' : ''}${num}${control.unit}`;
  }
  return `${num}${control.unit}`;
}

/* ============================================================
   Actions
   ============================================================ */
function selectPiece(category, pieceId) {
  if (state[category].pieceId === pieceId) return;
  state[category].pieceId = pieceId;
  renderGarment(category, { animate: true });
  updateCaption();
  updateActiveStates();
  renderFitControls(category);
  renderSizeControls(category);
  updateSizeMatch();
  saveState();
}

function selectTint(category, tintName) {
  state[category].tint = tintName;
  renderGarment(category);
  updateCaption();
  updateActiveStates();
  saveState();
}

function resetCurrentFit(evt) {
  const { pieceId } = state[activeCategory];
  state[activeCategory].fitByPiece[pieceId] = defaultFit();
  renderGarment(activeCategory, { animate: true });
  renderFitControls(activeCategory);
  saveState();
  if (evt && evt.currentTarget) {
    const btn = evt.currentTarget;
    btn.classList.remove('is-spinning');
    void btn.offsetWidth;
    btn.classList.add('is-spinning');
  }
}

function shuffleLook() {
  CATEGORIES.forEach((category) => {
    const options = WARDROBE[category];
    let piece = options[Math.floor(Math.random() * options.length)];
    // Avoid re-rolling the exact same piece so the button always visibly does something.
    if (options.length > 1 && piece.id === state[category].pieceId) {
      piece = options[(options.indexOf(piece) + 1) % options.length];
    }
    const tint = TINTS[Math.floor(Math.random() * TINTS.length)];
    state[category].pieceId = piece.id;
    state[category].tint = tint.name;
  });
  state.lookCount += 1;
  applyAll({ animate: true });
  updateLookNumber();
  saveState();
}

function updateLookNumber() {
  lookNumberEl.textContent = String(state.lookCount).padStart(3, '0');
}

/* ============================================================
   Worn Together mode — the two flat lays overlap into one outfit
   instead of resting side by side. Pure position/z-index change
   driven by a class on the scene; every existing piece/tint/fit
   control keeps acting on the same two <img> layers untouched.
   ============================================================ */
const wornToggleBtn = document.getElementById('wornToggleBtn');
const sceneEl = document.getElementById('tableScene');
const scaleLabelEl = document.querySelector('.table-scale');

function applyWornMode() {
  sceneEl.classList.toggle('is-worn', state.worn);
  wornToggleBtn.setAttribute('aria-pressed', String(state.worn));
  wornToggleBtn.setAttribute(
    'data-tip',
    state.worn ? 'Lay them flat again' : 'See them worn together'
  );
  const wornSpan = wornToggleBtn.querySelector('span');
  if (wornSpan) wornSpan.textContent = state.worn ? 'Flat lay' : 'Worn together';
  if (scaleLabelEl) {
    scaleLabelEl.firstChild.textContent = state.worn ? 'Worn ∶ true fit · ' : 'Scale 1∶4 · ';
  }
}

function toggleWorn() {
  state.worn = !state.worn;
  applyWornMode();
  renderGarment('jackets');
  updateCaption();
  // The pointer-tracked tilt (initTableMotion) only refreshes its
  // inline transform on the *next* pointermove — if the pointer
  // hasn't moved since the last one, the trouser layer would still
  // be carrying whatever transform was written before the toggle,
  // missing the worn-mode drop until the pointer happens to move.
  syncTiltToWornMode();
  saveState();
}

wornToggleBtn.addEventListener('click', toggleWorn);

function setActiveCategory(category) {
  activeCategory = category;

  document.querySelectorAll('.panel__tab').forEach((tab) => {
    tab.setAttribute('aria-selected', String(tab.dataset.category === category));
  });
  document.querySelectorAll('.category').forEach((section) => {
    section.hidden = section.dataset.category !== category;
  });

  const glide = document.getElementById('tabGlide');
  const index = CATEGORIES.indexOf(category);
  glide.style.transform = `translateX(${index * 100}%)`;

  renderFitControls(category);
  renderSizeControls(category);
}

/* ============================================================
   Build the panel (thumbnails + tint swatches) once on load
   ============================================================ */
function buildPanel() {
  CATEGORIES.forEach((category) => {
    const section = document.querySelector(`.category[data-category="${category}"]`);
    const piecesEl = section.querySelector('[data-role="pieces"]');
    const tintsEl = section.querySelector('[data-role="tints"]');

    WARDROBE[category].forEach((piece) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'piece-btn';
      btn.dataset.category = category;
      btn.dataset.pieceId = piece.id;
      btn.setAttribute('aria-label', `${piece.label}, ${piece.color}`);

      const img = document.createElement('img');
      img.src = piece.file;
      img.alt = '';
      btn.appendChild(img);

      btn.addEventListener('click', () => selectPiece(category, piece.id));
      piecesEl.appendChild(btn);
    });

    TINTS.forEach((tint) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'tint-btn';
      btn.dataset.category = category;
      btn.dataset.tint = tint.name;
      btn.style.backgroundColor = tint.swatch;
      btn.setAttribute('aria-label', `Tint: ${tint.name}`);

      btn.addEventListener('click', () => selectTint(category, tint.name));
      tintsEl.appendChild(btn);
    });
  });

  document.querySelectorAll('.panel__tab').forEach((tab) => {
    tab.addEventListener('click', () => setActiveCategory(tab.dataset.category));
  });
}

/* Shared with initGarmentDrag(): while a garment is being dragged
   by hand, the pointer-tracked tilt below must stop repositioning
   that same garment in 3D, or the two competing transforms fight
   over the same pointermove and the drag reads as jumpy/rotating
   instead of a plain, predictable nudge — worst at the bottom edge
   of a tall garment like the jacket, furthest from the tilt's pivot. */
let isGarmentDragging = false;
let stopTiltMotion = () => {};

/* Reassigned by initTableMotion() once it has real curX/curY state
   to read from. Re-stamps both tilt elements' inline transform with
   the current pointer-tracked angle *plus* the worn-mode trouser
   offset when relevant — see the long comment inside tick() for why
   that offset needs to be folded in here rather than left to CSS. */
let syncTiltToWornMode = () => {};

/* ============================================================
   Table motion: pointer-tracked tilt on each bay + custom cursor
   A single orchestrated interaction — the whole table reads as one
   lit object responding to where you're looking, rather than
   scattered per-element hover effects.
   ============================================================ */
function initTableMotion() {
  const scene = document.getElementById('tableScene');
  const cursor = document.getElementById('pinCursor');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (reduceMotion) return;

  let raf = null;
  let targetX = 0.5;
  let targetY = 0.5;
  let curX = 0.5;
  let curY = 0.5;

  // Called by initGarmentDrag() the instant a drag starts, so any
  // easing already in flight from the pointermove right before the
  // drag began doesn't keep nudging the tilt for a few more frames
  // after the drag has taken over.
  stopTiltMotion = () => {
    if (raf) {
      cancelAnimationFrame(raf);
      raf = null;
    }
    curX = targetX;
    curY = targetY;
  };

  function tick() {
    curX += (targetX - curX) * 0.08;
    curY += (targetY - curY) * 0.08;

    CATEGORIES.forEach((category) => {
      const el = tiltEls[category];
      if (!el) return;
      const rx = 6 - (curY - 0.5) * 10;
      const ry = -3 + (curX - 0.5) * 10;
      // Worn mode drops the trouser layer 4% lower than the jacket
      // (see .table-scene.is-worn .garment-bay--pants .garment-tilt
      // in the CSS) so the two pieces don't sit on the exact same
      // plane. That rule only wins as long as nothing here writes a
      // competing inline transform on the same element — an inline
      // style always beats a class — so the pointer-tracked tilt has
      // to carry the same offset itself while worn mode is active,
      // or every pointermove silently snaps the trouser back into
      // the jacket's plane the instant the pointer moves.
      const wornDrop = state.worn && category === 'pants' ? ' translateY(4%)' : '';
      el.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)${wornDrop}`;
    });

    if (Math.abs(targetX - curX) > 0.001 || Math.abs(targetY - curY) > 0.001) {
      raf = requestAnimationFrame(tick);
    } else {
      raf = null;
    }
  }

  function requestTick() {
    if (!raf) raf = requestAnimationFrame(tick);
  }

  syncTiltToWornMode = () => {
    CATEGORIES.forEach((category) => {
      const el = tiltEls[category];
      if (!el) return;
      const rx = 6 - (curY - 0.5) * 10;
      const ry = -3 + (curX - 0.5) * 10;
      const wornDrop = state.worn && category === 'pants' ? ' translateY(4%)' : '';
      el.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)${wornDrop}`;
    });
  };

  scene.addEventListener('pointermove', (e) => {
    cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
    cursor.classList.add('is-active');

    // A hand-drag in progress owns this garment's transform; let it,
    // instead of also rotating the piece out from under the pointer.
    if (isGarmentDragging) return;

    const rect = scene.getBoundingClientRect();
    targetX = (e.clientX - rect.left) / rect.width;
    targetY = (e.clientY - rect.top) / rect.height;
    requestTick();
  });

  scene.addEventListener('pointerleave', () => {
    targetX = 0.5;
    targetY = 0.5;
    requestTick();
    cursor.classList.remove('is-active');
  });

  scene.addEventListener('pointerdown', () => cursor.classList.add('is-down'));
  window.addEventListener('pointerup', () => cursor.classList.remove('is-down'));
}

document.getElementById('shuffleBtn').addEventListener('click', shuffleLook);
document.getElementById('resetFitBtn').addEventListener('click', resetCurrentFit);

buildPanel();
applyAll();
updateLookNumber();
applyWornMode();
setActiveCategory(activeCategory);
initTableMotion();
initGarmentDrag();
initScrollTableEffect();
initSplash();
initEntranceSequence();
initMastheadTitleReveal();
initSealWatermark();
initScrollSpine();
initDustField();
initAtelierChoreography();
initMagneticKnobs();

/* ============================================================
   Alpha maps — which pixels of each garment photo are actually
   fabric, not transparent PNG margin.

   Why this exists: in Worn Together mode the jacket bay is drawn
   on top of the trouser bay (z-index) so the jacket reads as worn
   over the waistband. But each bay's hit box is its *whole* square
   — including all the transparent margin around the actual photo —
   and a plain z-index/box hit test can't tell "the jacket's box is
   on top here" apart from "the jacket's *fabric* is on top here".
   In practice the jacket's box covers most of the trouser's visible
   area even where the jacket photo itself is empty (the gap under
   the sleeves, the open front, everything below the hem), so a
   press anywhere in that overlap used to always grab the jacket —
   the trouser was effectively undraggable while worn together, no
   matter where on the visible trouser fabric you pressed.

   The real fix is a per-pixel test: each garment PNG is reduced,
   offline, to a 64×64 opacity grid (1 = fabric, 0 = transparent),
   packed 8 cells to a byte and hex-encoded below. At pointerdown,
   hitTestGarment() maps the press back into that source image's own
   coordinate space — using the element's live, untransformed
   offsetWidth/offsetHeight for the object-fit:contain square, and
   its live getBoundingClientRect() for where that square currently
   sits on screen — so it stays correct through scale, size, drag
   offset, and the pointer-tracked tilt without re-deriving any of
   those transforms by hand. A press only "hits" a garment where
   that garment is actually opaque.

   Generated once from the source art (64×64 box-filtered alpha,
   threshold ≈10%); regenerate if a garment PNG is replaced.
   ============================================================ */
const ALPHA_GRID = 64;
const ALPHA_MAPS = {
  'jacket-01-bomber-black': '000000000000000000000000000000000000000000000000000000000000000000000000000000000000001ff80000000000003ffc0000000000003ffc000000000000ffff000000000003ffffc0000000000ffffff0000000003ffffffc00000000ffffffff00000001ffffffff80000003ffffffffc0000007ffffffffc0000007ffffffffe0000007ffffffffe000000ffffffffff000000ffffffffff000000ffffffffff000000ffffffffff000001ffffffffff800001ffffffffff800001ffffffffff800001ffffffffff800003ffffffffffc00003ffffffffffc00003ffffffffffc00003ffffffffffc00007ffffffffffe00007ffffffffffe00007ffffffffffe00007ffffffffffe00007ffffffffffe00007ffffffffffe0000ffffffffffff0000ffffffffffff0000ffffffffffff0000ffffffffffff0000ffffffffffff0000ffffffffffff0000ffbffffffdff0001ffbffffffdff8001ffbffffffdff8001ffbffffffdff8001ffbffffffdff8001ffbffffffdff8001ff3ffffffdff8001ff3ffffffcff8001ff1ffffff8ff8001ff1ffffff8ff8001ff1ffffff8ff8001fe1ffffff87f8001fe1ffffff87f8000fc0ffffff03f0000fc000000003f0000fc000000003f0000f8000000003f0000000000000000000000000000000000000000000000000000000000000000000000000000000000',
  'jacket-02-puffer-stone': '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff00000000000001ffc0000000000003ffc0000000000007ffe000000000003ffffc0000000000ffffff0000000003ffffffc000000007ffffffe00000000ffffffff00000001ffffffff80000003ffffffffc0000003ffffffffc0000007ffffffffe000000ffffffffff000000ffffffffff000001ffffffffff800001ffffffffff800003ffffffffffc00003ffffffffffc00007ffffffffffe00007ffffffffffe0000ffffffffffff0000ffffffffffff0000ffffffffffff0001ffffffffffff8001ffffffffffff8001ffffffffffff8003ffffffffffffc003ffffffffffffc003ffffffffffffc007ffffffffffffe007ffffffffffffe007ffffffffffffe007ffffffffffffe00ffffffffffffff00ffffffffffffff00ffffffffffffff00ffffffffffffff00ffffffffffffff81ffffffffffffff81ffffffffffffff81ffffffffffffff81ffffffffffffff81fffffffffff7ff81ffcffffffff3ff81ffcffffffff3ff81ff8ffffffff1ff81ff8ffffffff1ff80ff07ffffffe0ff00fe00000000007f00fc00000000003f003c00000000003c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
  'jacket-03-utility-charcoal': '0000000000000000000000000000000000000000000000000000000000000000000000fc3f000000000003ffffc0000000000ffffff0000000003ffffffc00000000ffffffff00000003ffffffffc0000007ffffffffe000000ffffffffff000000ffffffffff000001ffffffffff800003ffffffffffc00003ffffffffffc00007ffffffffffe0000ffffffffffff0000ffffffffffff8001ffffffffffff8003ffffffffffffc007ffffffffffffe007ffffffffffffe00ffffffffffffff01ffffffffffffff81ffffffffffffff83ffffffffffffffc3ffffffffffffffc1ffffffffffffff807fffffffffffff003ffffffffffffc001ffffffffffff00007ffffffffffe00001ffffffffff800000dffffffffb0000001ffffffff80000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000001ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc0000003ffffffffc000000000000000000000000000000000000000000000000000',
  'pants-01-tapered-charcoal': '00000000000000000000000000000000000007ffffe00000000007ffffe00000000007ffffe0000000000ffffff0000000000ffffff0000000001ffffff0000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000003ffffff8000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffffffc000000003ffe7ffc000000003ffe7ffc000000003ffe7ffc000000003ffe7ffc000000003ffe7ffc000000003ffe3ffc000000003ffc3ffc000000003ffc3ffc000000003ffc3ffc000000003ffc3ffc000000003ffc3ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff00ffc000000003ff80ffc000000003ff81ffc000000003ff81ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000001ff00ffc000000001ff00ff8000000001ff00ff8000000001ff007f8000000001fe007f8000000001fe007f8000000000fc003f0000000000fc003f0000000000fc003f00000000007c003e000000000038001c000000000000000000000',
  'pants-02-cargo-khaki': '00000000000000000000000000000000000007ffffe00000000007ffffe00000000007ffffe0000000000fffffe0000000000fffffe0000000000ffffff0000000000ffffff0000000001ffffff0000000001ffffff0000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000003ffffff8000000003ffffff8000000003ffffffc000000003ffffffc000000007ffffffc000000007ffffffe000000007ffffffc000000007ffffffe000000007ffffffe000000007ffffffe000000007ffffffe000000007ffffffe000000007ffffffe000000007ffffffe000000007ffffffe000000007ffefffe000000007ffe7ffe00000000fffe7ffe00000000fffe7fff00000000fffe7fff00000000fffe7fff00000000fffe7fff00000000fffe7fff00000000fffc7fff00000000fffc3fff00000000fffc3fff00000000fffc3fff00000000fffc3fff00000000fffc3fff00000000fffc3fff00000000fffc3fff000000007ff83ffe000000007ff81ffe000000007ff81ffe000000007ff81ffe000000007ff81ffe000000007ff81ffe000000007ff81ffe000000007ff00ffe000000003ff00ffc000000003ff00ffc000000003ff00ffc000000003ff00ffc000000001fe007f8000000001fe007f8000000001fe007f8000000000000000000000000000000000000',
  'pants-03-straight-black': '00000000000000000000000000000000000007ffffe00000000007fffff0000000000ffffff0000000000ffffff0000000000ffffff0000000000ffffff0000000000ffffff0000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffffff8000000001ffefff8000000001ffe7ff8000000001ffe7ff8000000001ffe7ff8000000001ffe7ff8000000001ffe7ff8000000001ffe7ff8000000001ffc7ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ffc3ff8000000001ff83ff8000000001ff81ff8000000001ff81ff8000000001ff81ff8000000001ff81ff8000000001ff81ff8000000001ff81ffc000000001ff81ffc000000001ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000003ff81ffc000000001ff01ff80000000007c003c000000000000000000000',
};

const alphaBytesCache = {};
function getAlphaBytes(pieceId) {
  if (!(pieceId in alphaBytesCache)) {
    const hex = ALPHA_MAPS[pieceId];
    if (!hex) {
      alphaBytesCache[pieceId] = null;
    } else {
      const bytes = new Uint8Array(hex.length / 2);
      for (let i = 0; i < bytes.length; i++) {
        bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
      }
      alphaBytesCache[pieceId] = bytes;
    }
  }
  return alphaBytesCache[pieceId];
}

function isOpaqueCell(pieceId, gx, gy) {
  const bytes = getAlphaBytes(pieceId);
  if (!bytes) return true; // no map for this piece — fail open rather than block a drag
  const index = gy * ALPHA_GRID + gx;
  const byte = bytes[index >> 3];
  return ((byte >> (7 - (index % 8))) & 1) === 1;
}

/* True if (clientX, clientY) lands on visible fabric of the given
   category's current garment, at its current on-screen position. */
function hitTestGarment(category, clientX, clientY) {
  const img = layerEls[category];
  const pieceId = state[category].pieceId;
  const bytes = getAlphaBytes(pieceId);
  if (!img || !bytes) return true;

  const rect = img.getBoundingClientRect();
  if (clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom) {
    return false;
  }

  // offsetWidth/Height are the element's *layout* box — unaffected
  // by the CSS `transform` that scales/moves it — which is exactly
  // the untransformed box object-fit:contain centers its square
  // photo inside. rect is that same box after the live transform,
  // so the square's current on-screen position/size scales with it.
  const w0 = img.offsetWidth || rect.width;
  const h0 = img.offsetHeight || rect.height;
  if (!w0 || !h0) return true;

  const side0 = Math.min(w0, h0);
  const fx = side0 / w0;
  const fy = side0 / h0;
  const sqWidth = rect.width * fx;
  const sqHeight = rect.height * fy;
  const sqLeft = rect.left + (rect.width - sqWidth) / 2;
  const sqTop = rect.top + (rect.height - sqHeight) / 2;

  if (clientX < sqLeft || clientX > sqLeft + sqWidth || clientY < sqTop || clientY > sqTop + sqHeight) {
    return false;
  }

  const su = (clientX - sqLeft) / sqWidth;
  const sv = (clientY - sqTop) / sqHeight;
  const gx = Math.min(ALPHA_GRID - 1, Math.max(0, Math.floor(su * ALPHA_GRID)));
  const gy = Math.min(ALPHA_GRID - 1, Math.max(0, Math.floor(sv * ALPHA_GRID)));
  return isOpaqueCell(pieceId, gx, gy);
}

/* Decides which garment a Worn Together press was actually meant
   for. `topCategory` is whichever bay's element the browser resolved
   the pointerdown to (always the jacket while its bay sits on top in
   z-index) — tried first, then the other one underneath it. */
function resolveWornPress(topCategory, clientX, clientY) {
  const otherCategory = topCategory === 'jackets' ? 'pants' : 'jackets';
  if (hitTestGarment(topCategory, clientX, clientY)) return topCategory;
  if (hitTestGarment(otherCategory, clientX, clientY)) return otherCategory;
  return null; // pressed empty transparent space over both bays
}

/* ============================================================
   Direct drag: press and drag a garment on the table to nudge its
   position by hand, instead of only through the Move X/Y sliders.
   Both write to the same fit.x/fit.y state, so a hand-drag and a
   slider drag pick up exactly where the other left off, and the
   panel's Fine-tune readout stays in sync either way.

   Drag state lives outside the per-category closures (one shared
   dragCategory instead of one dragging flag per garment), because
   in worn mode the garment that ends up being dragged can differ
   from the one whose element actually received the pointerdown —
   see resolveWornPress() above.
   ============================================================ */
function initGarmentDrag() {
  const xRange = FIT_CONTROLS.find((c) => c.key === 'x');
  const yRange = FIT_CONTROLS.find((c) => c.key === 'y');

  let dragCategory = null;
  let dragPointerId = null;
  let startClientX = 0;
  let startClientY = 0;
  let startFitX = 0;
  let startFitY = 0;

  function beginDrag(category, e) {
    const { pieceId } = state[category];
    const fit = getFit(category, pieceId);
    dragCategory = category;
    dragPointerId = e.pointerId;
    isGarmentDragging = true;
    stopTiltMotion();
    startClientX = e.clientX;
    startClientY = e.clientY;
    startFitX = fit.x;
    startFitY = fit.y;
    tiltEls[category].classList.add('is-dragging');
    // Captured on the *resolved* garment's own element (which may
    // not be the element the pointerdown actually landed on — see
    // resolveWornPress) rather than e.target; a capture target only
    // needs an active pointer with this id, not to be the original
    // hit-test result.
    try { tiltEls[category].setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
  }

  function endDrag() {
    if (!dragCategory) return;
    tiltEls[dragCategory].classList.remove('is-dragging');
    try { tiltEls[dragCategory].releasePointerCapture(dragPointerId); } catch (err) { /* already released */ }
    dragCategory = null;
    dragPointerId = null;
    isGarmentDragging = false;
    saveState();
  }

  CATEGORIES.forEach((category) => {
    const tilt = tiltEls[category];

    // The listeners live on the tilt container, not the <img> itself.
    // The image carries a CSS drop-shadow filter and, once the Fit
    // controls scale it past 100%, its own box grows well outside its
    // parent's — combined with the 3D perspective this table already
    // sits in, that made presses on the image itself register
    // inconsistently in testing (most noticeable on a heavily scaled
    // piece). The container has none of that — no filter, no scale —
    // so it catches every press, and any hit inside it still bubbles
    // up here whether the browser resolved it to the image or not.
    tilt.classList.add('is-draggable');
    tilt.addEventListener('dragstart', (e) => e.preventDefault());

    tilt.addEventListener('pointerdown', (e) => {
      const resolved = state.worn ? resolveWornPress(category, e.clientX, e.clientY) : category;
      if (!resolved) return;
      beginDrag(resolved, e);
    });
  });

  // Move/up/cancel live on window (not on the per-category tilt
  // elements) because the element that started the drag — via
  // pointer capture — is the *resolved* garment, which in worn mode
  // can be the one underneath the element the press actually landed
  // on. window still receives the captured pointer's events (capture
  // redirects the target, it doesn't stop bubbling), so this reaches
  // the same events the old per-element listeners did.
  window.addEventListener('pointermove', (e) => {
    if (!dragCategory || e.pointerId !== dragPointerId) return;
    const rect = tiltEls[dragCategory].getBoundingClientRect();
    const dxPct = ((e.clientX - startClientX) / rect.width) * 100;
    const dyPct = ((e.clientY - startClientY) / rect.height) * 100;
    const nextX = Math.max(xRange.min, Math.min(xRange.max, Math.round(startFitX + dxPct)));
    const nextY = Math.max(yRange.min, Math.min(yRange.max, Math.round(startFitY + dyPct)));

    setFit(dragCategory, state[dragCategory].pieceId, 'x', nextX);
    setFit(dragCategory, state[dragCategory].pieceId, 'y', nextY);
    renderGarment(dragCategory);
    if (activeCategory === dragCategory) {
      renderFitControls(dragCategory);
    }
  });

  window.addEventListener('pointerup', (e) => {
    if (e.pointerId !== dragPointerId) return;
    endDrag();
  });
  window.addEventListener('pointercancel', (e) => {
    if (e.pointerId !== dragPointerId) return;
    endDrag();
  });
}

/* ============================================================
   Scroll table effect: as the table scrolls up out of the first
   screen, it gains a very slight extra tilt and the lamp above it
   dims — the table reads as one lit object being carried away
   from the light, not a static image scrolling past a fixed lamp.
   Driven by the table's own position, so it plays out over exactly
   the distance the table takes to leave the viewport, then holds
   still for the rest of the page rather than tracking total scroll
   distance (which would keep changing for an arbitrarily long page).

   Extended below with the rest of the "clearing the table" exit:
   the whole scene recedes half a step into the dark as the lamp
   dims (not just tilts), and the control panel beside it swings
   shut like a drawer a beat later — staggered off the same scroll
   distance rather than firing together, so the workspace reads as
   being put away in two deliberate motions, not one flat fade.
   ============================================================ */
function initScrollTableEffect() {
  const wrap = document.querySelector('.table-wrap');
  const workspace = document.querySelector('.workspace');
  const panel = document.querySelector('.panel');
  if (!wrap) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return;

  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  // Cubic ease-in: near-zero at first, so the recede/drawer-close
  // only becomes noticeable in the second half of the exit rather
  // than starting to move the instant the reader begins scrolling.
  const easeInCubic = (t) => t * t * t;

  let ticking = false;

  function update() {
    ticking = false;
    const rect = wrap.getBoundingClientRect();

    // 0 when the table's top is at the top of the viewport, 1 once
    // its top has scrolled fully past the top of the viewport.
    const progress = clamp01(-rect.top / (rect.height || 1));

    wrap.style.setProperty('--scroll-tilt', `${(progress * 3.2).toFixed(2)}deg`);
    wrap.style.setProperty('--lamp-intensity', `${(1 - progress * 0.6).toFixed(2)}`);

    if (workspace) {
      // Recedes at most 3% — enough to read as "being carried back
      // into the dark," never enough to look like a scale bug.
      const recede = 1 - easeInCubic(progress) * 0.03;
      workspace.style.setProperty('--exit-scale', recede.toFixed(4));
    }

    if (panel) {
      // Starts a quarter of the way into the table's own exit and
      // finishes by the time the table is gone — the drawer shuts
      // just after the composition is set, not alongside it.
      const drawerProgress = clamp01((progress - 0.25) / 0.75);
      const eased = easeInCubic(drawerProgress);
      panel.style.setProperty('--drawer-close', eased.toFixed(3));
    }
  }

  function onScroll() {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(update);
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  update();
}
/* ============================================================
   Splash: full-viewport intro shown before the site, every load.
   The screen is genuinely, fully black (.splash__blackout in the
   CSS) — the walnut table underneath is at full true-color
   brightness the whole time, but a solid opaque sheet hides all of
   it except through a soft circular hole that tracks the lantern.
   The brass seal sits at zero opacity, not a dimmed hint, until the
   light's final pass parks on it and finds it for real.

   Five beats, back to back:
     1. WANDER   — the hole drifts across the wood at a few
                   unrelated stops, like someone searching in the dark.
     2. REVEAL   — final approach onto the seal; it brightens in.
     3. GROW     — the found mark visibly swells (scale + glow),
                   the hole widening slightly with it.
     4. FLASH    — a fast warm pulse right as the grow peaks.
     5. ZOOM     — the mark rushes forward and the whole splash
                   pushes out and dissolves, handing off to the
                   real page underneath.

   Everything here is driven frame-by-frame against one shared
   clock, so none of these stack extra CSS-transition easing on top
   of the JS easing — the numbers below are the full timeline.

   Respects prefers-reduced-motion: the whole overlay is hidden via
   CSS in that case, so this function's timers simply run against
   an invisible/already-gone element — harmless, no special-casing
   needed here beyond removal at the end either way. */
function initSplash() {
  const splash = document.getElementById('splash');
  if (!splash) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) {
    splash.remove();
    return;
  }

  const lantern = document.getElementById('splashLantern');
  const seal = document.getElementById('splashSeal');
  // .splash__wood / .splash__blackout / .splash__lantern are SIBLINGS under
  // .splash__scene, not nested inside one another — CSS custom properties
  // only cascade to descendants, so --lantern-x/y/radius must be written on
  // their shared parent (.splash__scene) for .splash__blackout's mask to
  // ever see them. Writing them on #splashLantern alone leaves the
  // blackout's mask permanently at its 0px fallback (never opens), so the
  // wood underneath is never actually revealed — only the lantern's own
  // glow bloom was ever visible, drawn over unbroken black.
  const scene = document.querySelector('.splash__scene') || lantern;

  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const easeInCubic = (t) => t * t * t;
  const easeInOutSine = (t) => -(Math.cos(Math.PI * t) - 1) / 2;
  const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const lerp = (a, b, t) => a + (b - a) * t;

  // The lantern's path across the table, as percentages of the
  // viewport so it scales cleanly at any size. "size" is in vmin —
  // a real, position-independent unit — NOT a percentage of the
  // mask's own farthest-corner distance (which used to make the
  // same "size" value read as a bigger or smaller hole depending on
  // where on screen the beam happened to be). The first four stops
  // wander the wood without ever reaching the seal (which sits at
  // 50/50); the final waypoint is the approach that ends centered on
  // it — that whole leg is also where the seal gets uncovered piece
  // by piece, see the per-frame seal-mask block below. Timed in
  // absolute ms (not fractions of one shared duration) so the phases
  // below can be scheduled against the same clock without
  // compounding two easing curves together.
  const waypoints = [
    { x: 22, y: 70, at: 0,    size: 12 },
    { x: 74, y: 66, at: 750,  size: 13 },
    { x: 78, y: 28, at: 1500, size: 12 },
    { x: 26, y: 24, at: 2150, size: 13 },
    { x: 50, y: 50, at: 4200, size: 13 }, // arrival — approach + discovery happen on this leg
  ];
  const ARRIVAL_AT = waypoints[waypoints.length - 1].at;

  // COVER: the closing part of the approach. The seal is uncovered
  // organically wherever the beam's real position happens to overlap
  // it (see seal-mask math below) for most of the final leg — that's
  // what makes the reveal read as "discovered piece by piece, from
  // whichever side the light is coming from" rather than a scripted
  // wipe. In just this last stretch before arrival, that organic
  // radius is blended up to one guaranteed to cover the whole mark,
  // so "it settles and the complete logo is there" never depends on
  // the wandering path having happened to end up centered enough.
  const COVER_DURATION = 950;
  const COVER_START = ARRIVAL_AT - COVER_DURATION;

  // GROW: the mark's own "it's found" beat — a small, deliberate
  // swell and a warm glow, not a dramatic scale-up. The wood hole
  // widens a little in sympathy so the light itself feels like it's
  // blooming open around the mark.
  const GROW_START = ARRIVAL_AT + 150;
  const GROW_DURATION = 560;
  const GROW_END = GROW_START + GROW_DURATION;

  // FLASH: a fast pulse timed to land right as GROW peaks.
  const FLASH_START = GROW_END - 110;
  const FLASH_DURATION = 380;
  const FLASH_END = FLASH_START + FLASH_DURATION;

  // ZOOM: the professional hand-off — mark rushes forward and
  // dissolves as the whole splash lifts (scale up slightly, fade
  // out) to reveal the real page beneath. Driven as a plain opacity
  // fade on the splash itself rather than a growing mask, so the
  // hand-off is always a clean, complete reveal regardless of
  // viewport size or aspect ratio.
  const ZOOM_START = GROW_END;
  const ZOOM_DURATION = 620;
  const ZOOM_END = ZOOM_START + ZOOM_DURATION;

  const DISMISS_AT = ZOOM_END + 100;

  lantern.style.setProperty('--lantern-opacity', '1');
  seal.style.setProperty('--seal-reveal', '1'); // a simple on/off gate now — the mask below does the real reveal

  const start = performance.now();
  let sealLitAdded = false;
  let transitioningAdded = false;

  function frame(now) {
    const elapsed = now - start;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const vmin = Math.min(vw, vh);

    // --- Lantern position along the waypoint path (viewport %, vmin size) ---
    let seg = waypoints[0];
    let next = waypoints[waypoints.length - 1];
    for (let i = 0; i < waypoints.length - 1; i += 1) {
      if (elapsed >= waypoints[i].at && elapsed <= waypoints[i + 1].at) {
        seg = waypoints[i];
        next = waypoints[i + 1];
        break;
      }
    }
    const segDuration = next.at - seg.at || 1;
    const localT = clamp01((elapsed - seg.at) / segDuration);
    const onFinalLeg = next === waypoints[waypoints.length - 1];
    // The final approach uses easeInOutCubic (slow-in, slow-out) rather than
    // easeOutCubic (fast-in, slow-out) — the whole point of this leg is to
    // read as a gentle, deliberate approach, not a quick dart that then
    // coasts to a stop.
    const eased = onFinalLeg ? easeInOutCubic(localT) : easeInOutSine(localT);
    const x = lerp(seg.x, next.x, eased);
    const y = lerp(seg.y, next.y, eased);
    let sizeVmin = lerp(seg.size, next.size, eased);

    // --- Seal: masked spatially by this SAME beam, translated into
    //     the seal's own local box (it's a fixed, centered square, so
    //     its geometry can be computed directly rather than read back
    //     from a transformed bounding rect). Whatever part of the
    //     mark the beam is currently over gets uncovered; nothing
    //     else does — exactly the same rule the wood follows.
    //
    //     Gated to onFinalLeg ONLY: the wandering path (waypoints 0-3)
    //     can pass geometrically close to dead-center on its way between
    //     stops (e.g. the first leg drifts right under the seal's
    //     bounding box around its midpoint) even though it's never
    //     meant to touch the mark. Without this gate the seal would
    //     "peek" — a stray sliver of the logo flashing into view mid-
    //     wander — before the real, intentional approach begins. Forcing
    //     the radius to 0 off the final leg guarantees the mark stays
    //     genuinely absent until the beam is deliberately walking toward
    //     it, so the only reveal anyone ever sees is the real one. ---
    const sealSize = Math.min(0.46 * vw, 0.46 * vh, 380);
    const sealLeft = vw / 2 - sealSize / 2;
    const sealTop = vh / 2 - sealSize / 2;
    const lanternRadiusPx = (sizeVmin / 100) * vmin;
    const lanternPxX = (x / 100) * vw;
    const lanternPxY = (y / 100) * vh;
    const localX = ((lanternPxX - sealLeft) / sealSize) * 100;
    const localY = ((lanternPxY - sealTop) / sealSize) * 100;

    // easeInOutCubic gives a slow, deliberate start to the cover blend
    // (about 6% covered a quarter of the way through the window, versus
    // ~58% with the old easeOutCubic) so the mark visibly builds rather
    // than snapping to "basically found" almost immediately.
    const coverT = clamp01((elapsed - COVER_START) / COVER_DURATION);
    const coverBlend = onFinalLeg ? easeInOutCubic(coverT) : 0;
    const sealCoverRadiusPx = sealSize * 0.78; // comfortably covers the whole mark once "found"
    const sealMaskRadiusPx = onFinalLeg ? lerp(lanternRadiusPx, sealCoverRadiusPx, coverBlend) : 0;

    let sealScale = 0.97 + coverBlend * 0.03; // 0.97 -> 1.0 as it's found — a subtle settle, not a jump
    let sealGlow = coverBlend * 10;
    let sealRevealOverride = null; // null = stay fully on; only the zoom phase below overrides this

    // --- Grow: found — small, deliberate swell + warm glow ---
    if (elapsed >= GROW_START) {
      const growE = easeOutCubic(clamp01((elapsed - GROW_START) / GROW_DURATION));
      sealScale = 1.0 + growE * 0.18;    // 1.0 -> 1.18
      sealGlow = 10 + growE * 24;        // 10 -> 34
      sizeVmin = 13 + growE * 7;         // 13vmin -> 20vmin
    }

    // --- Flash: a fast warm pulse right as the grow peaks ---
    if (elapsed >= FLASH_START && elapsed < FLASH_END) {
      splash.classList.add('is-flashing');
    } else if (elapsed >= FLASH_END) {
      splash.classList.remove('is-flashing');
    }

    // --- Zoom: mark rushes forward and dissolves; splash lifts and
    //     fades — the professional hand-off into the real page ---
    let splashScale = 1;
    let splashOpacity = 1;
    let lanternOpacity = 1;
    if (elapsed >= ZOOM_START) {
      if (!transitioningAdded) {
        transitioningAdded = true;
        splash.classList.add('is-transitioning');
      }
      const zoomT = clamp01((elapsed - ZOOM_START) / ZOOM_DURATION);
      sealScale = 1.18 + easeInCubic(zoomT) * 0.22;       // 1.18 -> 1.40
      sealRevealOverride = clamp01(1 - easeInOutCubic(zoomT) * 1.15);
      splashScale = 1 + easeInOutCubic(zoomT) * 0.06;
      splashOpacity = clamp01(1 - easeInOutCubic(zoomT));
      lanternOpacity = clamp01(1 - zoomT);
    }

    scene.style.setProperty('--lantern-x', `${x.toFixed(2)}%`);
    scene.style.setProperty('--lantern-y', `${y.toFixed(2)}%`);
    scene.style.setProperty('--lantern-radius', `${sizeVmin.toFixed(2)}vmin`);
    scene.style.setProperty('--lantern-glow-radius', `${(sizeVmin * 1.35).toFixed(2)}vmin`);
    scene.style.setProperty('--lantern-core-radius', `${(sizeVmin * 0.7).toFixed(2)}vmin`);
    scene.style.setProperty('--lantern-opacity', lanternOpacity.toFixed(3));

    seal.style.setProperty('--seal-mask-x', `${localX.toFixed(2)}%`);
    seal.style.setProperty('--seal-mask-y', `${localY.toFixed(2)}%`);
    seal.style.setProperty('--seal-mask-radius', `${sealMaskRadiusPx.toFixed(2)}px`);
    seal.style.setProperty('--seal-scale', sealScale.toFixed(3));
    seal.style.setProperty('--seal-glow', sealGlow.toFixed(1));
    seal.style.setProperty('--seal-reveal', (sealRevealOverride === null ? 1 : sealRevealOverride).toFixed(3));

    if (elapsed >= waypoints[3].at && !sealLitAdded) {
      sealLitAdded = true;
      splash.classList.add('is-seal-lit');
    }

    splash.style.opacity = splashOpacity.toFixed(3);
    splash.style.transform = `scale(${splashScale.toFixed(4)})`;

    if (elapsed < DISMISS_AT) {
      requestAnimationFrame(frame);
    } else {
      splash.remove();
    }
  }
  requestAnimationFrame(frame);
}
/* ============================================================
   Entrance sequence: the table arrives as one connected moment
   instead of the scene simply being "on" from the first frame.

     1. Scrim fades out while the lamp warms up (--entrance-scrim
        1 → 0, --lamp-entrance 0 → 1 on .table-wrap, composed with
        the existing scroll-driven --lamp-intensity via calc() in
        CSS, so this never fights the scroll dimming).
     2. Stitch divider unspools top-to-bottom (--stitch-reveal 0 → 1
        via clip-path inset on .stitch-divider).

   The garments are NOT re-animated here. applyAll() already laid
   them down statically before this runs, so they simply sit under
   the scrim and are revealed as it fades with the lamp — one
   continuous reveal, not a second motion stacked on top. The
   garment-fold-in/garment-settle animation is reserved entirely for
   later swaps (new piece picked, size changed, shuffle, etc.) so
   the first thing a visitor sees isn't followed by a second,
   different-looking "arrival" for the same garments a moment later.

   All custom properties default to their "settled" value in CSS
   (scrim invisible, lamp fully on, stitch fully drawn), so the page
   is already correct if this function bails early. Respects
   prefers-reduced-motion the same way initScrollTableEffect() does:
   skip the choreography, jump straight to the end state. */
function initEntranceSequence() {
  const wrap = document.querySelector('.table-wrap');
  if (!wrap) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return;

  // Start dark/undrawn before the first paint, then run the
  // sequence — avoids a flash of the fully-lit resting state.
  wrap.style.setProperty('--entrance-scrim', '1');
  wrap.style.setProperty('--lamp-entrance', '0');
  wrap.style.setProperty('--stitch-reveal', '0');

  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

  const LAMP_DELAY = 150;    // let the seal/title reveal begin first
  const LAMP_DURATION = 900;
  const STITCH_DELAY = LAMP_DELAY + 550;   // overlaps the lamp's tail end
  const STITCH_DURATION = 500;

  const start = performance.now();

  function frame(now) {
    const elapsed = now - start;

    const lampT = clamp01((elapsed - LAMP_DELAY) / LAMP_DURATION);
    const lampEased = easeOutCubic(lampT);
    wrap.style.setProperty('--lamp-entrance', lampEased.toFixed(3));
    wrap.style.setProperty('--entrance-scrim', (1 - lampEased).toFixed(3));

    const stitchT = clamp01((elapsed - STITCH_DELAY) / STITCH_DURATION);
    wrap.style.setProperty('--stitch-reveal', easeOutCubic(stitchT).toFixed(3));

    if (lampT < 1 || stitchT < 1) {
      requestAnimationFrame(frame);
    }
  }

  requestAnimationFrame(frame);
}
/* ============================================================
   Masthead title reveal: each word of the H1 sits in its own
   overflow-hidden window and rises up into place on load, staggered
   left to right — type being set, rather than the whole headline
   fading in as one flat block. Pure progressive enhancement: if
   this never runs (or reduced motion is on), the title is already
   there as plain, fully-formed text; nothing depends on it.
   ============================================================ */
function wrapTitleWords(el) {
  const frag = document.createDocumentFragment();
  let wordIndex = 0;

  Array.from(el.childNodes).forEach((node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      node.textContent.split(/(\s+)/).forEach((token) => {
        if (token === '') return;
        if (/^\s+$/.test(token)) {
          frag.appendChild(document.createTextNode(token));
          return;
        }
        const word = document.createElement('span');
        word.className = 'word';
        const inner = document.createElement('span');
        inner.className = 'word__inner';
        inner.textContent = token;
        inner.style.setProperty('--i', String(wordIndex));
        wordIndex += 1;
        word.appendChild(inner);
        frag.appendChild(word);
      });
    } else {
      frag.appendChild(node.cloneNode(true));
    }
  });

  el.innerHTML = '';
  el.appendChild(frag);
}

function initMastheadTitleReveal() {
  const title = document.querySelector('.masthead__title');
  if (!title) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return; // leave the plain, static text exactly as authored

  wrapTitleWords(title);
}

/* ============================================================
   Seal watermark: a small stand-in for the masthead seal that
   fades in once the real one has scrolled out past the top of the
   viewport, and keeps a slow, continuous spin from then on — a
   quiet signal that the page is still "alive" no matter how far
   down the reader has gone, without competing with the table's own
   motion up top.
   ============================================================ */
function initSealWatermark() {
  const seal = document.querySelector('.masthead__seal');
  const watermark = document.getElementById('sealWatermark');
  if (!seal || !watermark || !('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        // Only count it as "scrolled past" when the seal has left
        // via the *top* of the viewport — not simply whenever it
        // stops intersecting for any other reason (e.g. before the
        // page has scrolled at all, on unusual viewport sizes).
        const scrolledPastTop = entry.boundingClientRect.top < 0;
        watermark.classList.toggle('is-visible', !entry.isIntersecting && scrolledPastTop);
      });
    },
    { threshold: 0 }
  );

  observer.observe(seal);
}

/* ============================================================
   Scroll spine: a brass measuring thread run down the page edge —
   this site's own version of a scroll progress bar, styled like
   the tailor's tape the rest of the interface already leans on
   (the table's ruler ticks, the "Scale 1∶4" readout). A pin eases
   toward the reader's actual position rather than snapping to it,
   and tick marks — one per major section — light up in brass as
   each is passed. Built entirely here; nothing in the markup
   hard-codes a percentage, so it stays correct if a section above
   ever changes height.
   ============================================================ */
function initScrollSpine() {
  const spine = document.getElementById('scrollSpine');
  if (!spine) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const track = document.createElement('div');
  track.className = 'scroll-spine__track';

  const fill = document.createElement('div');
  fill.className = 'scroll-spine__fill';

  const waypoints = [
    { el: document.querySelector('.table-wrap'), label: 'Table' },
    ...Array.from(document.querySelectorAll('.atelier__note')).map((note) => {
      const idx = note.querySelector('.atelier__index');
      return { el: note, label: idx ? idx.textContent.trim() : '' };
    }),
    { el: document.querySelector('.atelier__close'), label: 'Close' },
  ].filter((wp) => wp.el);

  const ticks = waypoints.map((wp) => {
    const el = document.createElement('span');
    el.className = 'scroll-spine__tick';
    el.dataset.label = wp.label;
    return { el, target: wp.el, pct: 0 };
  });

  const pin = document.createElement('div');
  pin.className = 'scroll-spine__pin';

  const readout = document.createElement('div');
  readout.className = 'scroll-spine__readout';
  readout.textContent = '0%';

  spine.appendChild(track);
  spine.appendChild(fill);
  ticks.forEach((t) => spine.appendChild(t.el));
  spine.appendChild(pin);
  spine.appendChild(readout);

  function maxScroll() {
    return Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  }

  function docTop(el) {
    return el.getBoundingClientRect().top + window.scrollY;
  }

  // Tick positions are section anchors — they only need to move
  // when layout actually reflows (resize, images finishing load),
  // not on every scroll frame, so they're measured separately from
  // the per-frame pin/fill update below.
  function layoutTicks() {
    const max = maxScroll();
    ticks.forEach((t) => {
      t.pct = Math.min(100, Math.max(0, (docTop(t.target) / max) * 100));
      t.el.style.top = `${t.pct}%`;
    });
  }

  function paint(pct) {
    fill.style.height = `${pct}%`;
    pin.style.top = `${pct}%`;
    readout.style.top = `${pct}%`;
    readout.textContent = `${Math.round(pct)}%`;
    ticks.forEach((t) => t.el.classList.toggle('is-passed', pct >= t.pct - 0.5));
  }

  let curPct = 0;
  let raf = null;

  function tick() {
    const target = (window.scrollY / maxScroll()) * 100;
    curPct += (target - curPct) * 0.16;
    paint(curPct);
    if (Math.abs(target - curPct) > 0.05) {
      raf = requestAnimationFrame(tick);
    } else {
      curPct = target;
      paint(curPct);
      raf = null;
    }
  }

  function onScroll() {
    if (reduceMotion) {
      // No trailing ease — the pin should just reflect scroll
      // position directly, like a plain, literal progress bar.
      paint((window.scrollY / maxScroll()) * 100);
      return;
    }
    if (!raf) raf = requestAnimationFrame(tick);
  }

  function onResize() {
    layoutTicks();
    onScroll();
  }

  layoutTicks();
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onResize);
  window.addEventListener('load', onResize);
  onScroll();
}

/* ============================================================
   Ambient dust field: a couple dozen brass-lit specks suspended in
   the room, each idling inside its own small radius rather than
   travelling anywhere — motion that never stops, independent of
   scroll, layered underneath the scroll-driven effects elsewhere so
   the room reads as lit and inhabited even while the reader is
   holding still. The field as a whole also carries a gentle
   scroll-linked parallax drift, so it isn't purely idle either.
   ============================================================ */
function initDustField() {
  const field = document.getElementById('dustField');
  if (!field) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const narrowScreen = window.matchMedia('(max-width: 640px)').matches;
  if (reduceMotion || narrowScreen) return; // matches the CSS fallback — skip building what nobody will see

  const COUNT = 22;
  for (let i = 0; i < COUNT; i++) {
    const mote = document.createElement('span');
    mote.className = 'dust-mote';
    const hoverDur = 10 + Math.random() * 10;
    const fadeDur = 6 + Math.random() * 9;
    mote.style.setProperty('--x', `${(Math.random() * 100).toFixed(1)}%`);
    mote.style.setProperty('--y', `${(Math.random() * 100).toFixed(1)}%`);
    mote.style.setProperty('--size', `${(1.8 + Math.random() * 2.2).toFixed(1)}px`);
    mote.style.setProperty('--dur', `${hoverDur.toFixed(1)}s`);
    // Negative delays start each cycle already in progress, on two
    // independent clocks (hover + fade), so no two motes are ever
    // in visible lockstep and the field never reads as "just reset".
    mote.style.setProperty('--delay', `${(-Math.random() * hoverDur).toFixed(1)}s`);
    mote.style.setProperty('--fade-dur', `${fadeDur.toFixed(1)}s`);
    mote.style.setProperty('--fade-delay', `${(-Math.random() * fadeDur).toFixed(1)}s`);
    // A small private wander radius — real dust suspended in a
    // light beam, not a particle with somewhere to be.
    mote.style.setProperty('--wx', `${(6 + Math.random() * 14).toFixed(1)}px`);
    mote.style.setProperty('--wy', `${(6 + Math.random() * 14).toFixed(1)}px`);
    mote.style.setProperty('--peak', (0.25 + Math.random() * 0.35).toFixed(2));
    field.appendChild(mote);
  }

  let ticking = false;
  function update() {
    ticking = false;
    const drift = Math.max(-140, window.scrollY * -0.05);
    field.style.setProperty('--dust-drift', `${drift.toFixed(1)}px`);
  }
  function onScroll() {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(update);
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  update();
}

/* ============================================================
   Atelier choreography: everything below the table is driven off
   one idea, repeated at different scales — continuous, reversible
   progress values computed straight from each element's own
   position in the viewport (the same technique as the table's
   scroll tilt/lamp effect above), rather than a class that flips
   on once and goes inert. A single scroll listener drives all of
   it — the header seam stitching shut, the connecting thread
   unspooling behind the three numbers, each note's number/title/
   body cascading in on one shared progress value, and the closing
   line's own seam.
   ============================================================ */
function initAtelierChoreography() {
  const atelierEl = document.querySelector('.atelier');
  const seamEl = document.getElementById('atelierSeam');
  const threadEl = document.getElementById('atelierThread');
  const kickerEl = document.querySelector('.atelier__kicker');
  const notes = Array.from(document.querySelectorAll('.atelier__note'));
  const closeEl = document.querySelector('.atelier__close');
  if (!atelierEl || !notes.length) return;

  const firstIdx = notes[0].querySelector('.atelier__index');
  const lastIdx = notes[notes.length - 1].querySelector('.atelier__index');

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const vh = () => window.innerHeight || document.documentElement.clientHeight;
  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

  // progress 0 → 1 as an element's top travels from startFrac·vh
  // (low on screen — just arriving) up to endFrac·vh (higher up —
  // settled). Reused for every element below with different zones.
  function zoneProgress(rect, startFrac, endFrac) {
    const start = startFrac * vh();
    const end = endFrac * vh();
    return clamp01((start - rect.top) / (start - end));
  }

  let threadAnchors = null;
  function measureThread() {
    if (!threadEl || !firstIdx || !lastIdx || notes.length < 2) return;
    const aRect = atelierEl.getBoundingClientRect();
    const fRect = firstIdx.getBoundingClientRect();
    const lRect = lastIdx.getBoundingClientRect();
    const top = (fRect.top - aRect.top) + fRect.height / 2;
    const bottom = (lRect.top - aRect.top) + lRect.height / 2;
    threadEl.style.left = `${(fRect.left - aRect.left) + fRect.width / 2}px`;
    threadEl.style.top = `${top}px`;
    threadEl.style.height = `${Math.max(0, bottom - top)}px`;
    // Absolute document-Y positions (unaffected by scroll), cached
    // so the per-frame update below doesn't need to re-measure.
    threadAnchors = {
      firstAbsY: fRect.top + window.scrollY + fRect.height / 2,
      lastAbsY: lRect.top + window.scrollY + lRect.height / 2,
    };
  }

  if (reduceMotion) {
    measureThread();
    if (seamEl) {
      seamEl.style.setProperty('--seam', '1');
      seamEl.style.setProperty('--seam-active', '0');
    }
    if (threadEl) threadEl.style.setProperty('--thread', '1');
    if (closeEl) closeEl.style.setProperty('--close-seam', '1');
    return; // everything else stays plain, static CSS — no scrubbing
  }

  const noteState = notes.map(() => ({ stamped: false }));
  let ticking = false;

  function update() {
    ticking = false;

    if (seamEl) {
      const r = seamEl.getBoundingClientRect();
      const p = easeOutCubic(zoneProgress(r, 0.98, 0.72));
      seamEl.style.setProperty('--seam', p.toFixed(3));
      seamEl.style.setProperty('--seam-active', p > 0.015 && p < 0.985 ? '1' : '0');
    }

    if (kickerEl) {
      const r = kickerEl.getBoundingClientRect();
      const p = easeOutCubic(zoneProgress(r, 0.94, 0.62));
      kickerEl.style.opacity = p.toFixed(3);
      kickerEl.style.transform = `translateY(${((1 - p) * 14).toFixed(1)}px)`;
      kickerEl.style.letterSpacing = `${(0.12 + (1 - p) * 0.22).toFixed(3)}em`;
    }

    notes.forEach((note, i) => {
      const r = note.getBoundingClientRect();
      const p = zoneProgress(r, 0.94, 0.4);

      const indexEl = note.querySelector('.atelier__index');
      const titleEl = note.querySelector('.atelier__title');
      const bodyEl = note.querySelector('.atelier__body');

      // The number lands first — no phase offset — so it reads as
      // the thing that cues the rest of the note to unfold.
      if (indexEl) {
        const pi = easeOutCubic(clamp01(p / 0.55));
        indexEl.style.opacity = pi.toFixed(3);
        indexEl.style.transform =
          `translateY(${((1 - pi) * 26).toFixed(1)}px) scale(${(0.55 + 0.45 * pi).toFixed(3)}) rotate(${((1 - pi) * -9).toFixed(1)}deg)`;
        indexEl.style.filter = pi < 0.999 ? `blur(${((1 - pi) * 5).toFixed(2)}px)` : 'none';

        // One-shot glint the instant the number finishes landing —
        // lives on a pseudo-element (see CSS) so it never fights
        // with the transform this same block keeps overwriting.
        // Re-arms once the number has scrolled meaningfully back
        // out, so it can replay if the reader returns to it later.
        const st = noteState[i];
        if (pi >= 0.985 && !st.stamped) {
          st.stamped = true;
          indexEl.classList.remove('is-stamped');
          void indexEl.offsetWidth;
          indexEl.classList.add('is-stamped');
        } else if (pi < 0.9 && st.stamped) {
          st.stamped = false;
        }
      }

      // Title unwinds next, like a dye pressing left-to-right
      // through the fabric — a clip-path wipe rather than a fade.
      if (titleEl) {
        const pt = easeOutCubic(clamp01((p - 0.08) / 0.7));
        const inset = `inset(0 ${((1 - pt) * 100).toFixed(2)}% 0 0)`;
        titleEl.style.clipPath = inset;
        titleEl.style.webkitClipPath = inset;
        titleEl.style.transform = `translateX(${((1 - pt) * -14).toFixed(1)}px)`;
        titleEl.style.opacity = (0.5 + 0.5 * pt).toFixed(3);
      }

      // Body follows last — same wipe, plus a soft blur/lift so it
      // reads as settling into focus rather than simply un-clipping.
      if (bodyEl) {
        const pb = easeOutCubic(clamp01((p - 0.16) / 0.78));
        const inset = `inset(0 ${((1 - pb) * 100).toFixed(2)}% 0 0)`;
        bodyEl.style.clipPath = inset;
        bodyEl.style.webkitClipPath = inset;
        bodyEl.style.transform = `translateY(${((1 - pb) * 14).toFixed(1)}px)`;
        bodyEl.style.filter = pb < 0.999 ? `blur(${((1 - pb) * 3).toFixed(2)}px)` : 'none';
        bodyEl.style.opacity = (0.4 + 0.6 * pb).toFixed(3);
      }
    });

    if (threadEl && threadAnchors) {
      const span = Math.max(1, threadAnchors.lastAbsY - threadAnchors.firstAbsY);
      const readLine = window.scrollY + vh() * 0.55;
      const pThread = clamp01((readLine - threadAnchors.firstAbsY) / span);
      threadEl.style.setProperty('--thread', pThread.toFixed(3));
    }

    if (closeEl) {
      const r = closeEl.getBoundingClientRect();
      const p = easeOutCubic(zoneProgress(r, 0.95, 0.68));
      closeEl.style.opacity = p.toFixed(3);
      closeEl.style.transform = `translateY(${((1 - p) * 16).toFixed(1)}px)`;
      closeEl.style.setProperty('--close-seam', p.toFixed(3));
    }
  }

  function onScroll() {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(update);
    }
  }

  function onResize() {
    measureThread();
    update();
  }

  measureThread();
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onResize);
  window.addEventListener('load', onResize);
  update();
}

/* ============================================================
   Magnetic knobs: the three masthead buttons lean slightly toward
   the pointer as it approaches, on top of (not instead of) their
   existing hover/press states — a small tactile flourish for fine
   pointers only. --mx/--my default to 0px in CSS, so keyboard and
   touch users see the plain, static button.
   ============================================================ */
function initMagneticKnobs() {
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!finePointer || reduceMotion) return;

  const STRENGTH = 0.28;
  const MAX_OFFSET = 7; // px

  document.querySelectorAll('.knob').forEach((btn) => {
    btn.addEventListener('pointermove', (e) => {
      const rect = btn.getBoundingClientRect();
      const relX = e.clientX - (rect.left + rect.width / 2);
      const relY = e.clientY - (rect.top + rect.height / 2);
      const mx = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, relX * STRENGTH));
      const my = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, relY * STRENGTH));
      btn.style.setProperty('--mx', `${mx.toFixed(1)}px`);
      btn.style.setProperty('--my', `${my.toFixed(1)}px`);
    });

    btn.addEventListener('pointerleave', () => {
      btn.style.setProperty('--mx', '0px');
      btn.style.setProperty('--my', '0px');
    });
  });
}
