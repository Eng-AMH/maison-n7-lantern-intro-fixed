# Prompt: Neutralize a garment photo to a light-gray recolor base

Use this prompt with any AI image tool (background/product editing tools,
Midjourney editor, DALL·E edit, Photoshop generative fill, etc.) whenever you
add a new garment photo to the wardrobe app. It converts the garment's color
to a light neutral gray while keeping every shading, fold, seam, and shadow
detail intact — exactly the base needed for the app's CSS tint filters
(grayscale + sepia + hue-rotate) to produce clean, saturated colors instead
of dull, dark ones.

---

## Full prompt (paste as-is)

```
Recolor this garment to a neutral light gray, while perfectly preserving
every existing detail: fabric folds, seams, stitching, zippers, buttons,
pockets, ribbing, and all shading and shadow gradients exactly as they
appear now.

Remap the garment's tones so the darkest shadow areas land around 70%
brightness (RGB ~180) and the lightest highlight areas land around 92%
brightness (RGB ~235) — a light warm-neutral gray, not pure white and not
mid-gray. Keep the relative contrast between light and shadow areas the
same as the original (i.e. scale/remap the existing luminance range into
this new lighter range; do not flatten it to one flat color).

Do not change the garment's shape, silhouette, texture, or any hardware
color (zippers, buttons, drawstrings can stay a neutral gray/silver tone
too). Do not add any new background — keep the background fully
transparent (alpha channel preserved), isolated on transparent PNG, same
canvas size and same garment position/scale as the source image.

No colored tint, no warm or cool color cast — strictly neutral grayscale
remapped into a light range. Output as a high-resolution transparent PNG,
product-catalog style, sharp focus, no added lighting effects or
reflections beyond what already exists in the source.
```

---

## Short version (for tools with a character limit)

```
Recolor this garment to a neutral light gray (shadows ~70% brightness,
highlights ~92% brightness), preserving all folds, seams, stitching and
shading exactly as-is. Keep transparent background, same pose and scale.
No color tint — strictly neutral gray, not pure white, not mid-gray.
Output as transparent PNG.
```

---

## Why these specific numbers

- **Pure white (RGB 255) is too flat** — it erases shadow detail, so the
  garment looks like a paper cutout with no folds or depth.
- **Mid-gray (RGB ~128) is too dark** — CSS color filters (grayscale +
  sepia + hue-rotate) need bright source pixels to produce vivid,
  saturated colors; starting from mid-gray or darker produces muddy,
  underlit results no matter what hue is dialed in.
- **~180–235 (70–92% brightness)** is the sweet spot tested against this
  project's actual tint presets (Natural, Charcoal, Stone, Olive, Rust,
  Bone) — it keeps enough shadow contrast to read as a real garment while
  giving every tint filter enough headroom to render clean and saturated.

## One trade-off to know about

This base was tested against every tint in the app. Darker tints (Rust,
Olive, Charcoal, Stone) come out clean and saturated at this brightness —
that's the main win. But the palette's own lightest tint, **Bone**,
brightens further on top of an already-light base, so folds and stitching
can look slightly washed out on garments that were also naturally light
to begin with (e.g. a puffer already shot in a pale stone color).

This is a minor, garment-by-garment effect, not a flaw in the approach —
most garments will look noticeably better across the whole tint range.
If a specific piece looks too washed out under Bone after recoloring,
nudge that image's target range down slightly (e.g. 165–220 instead of
180–235) to bring a bit more shadow contrast back.

## After recoloring

Drop the new PNG into the matching `assets/images/<category>/` folder,
then add its real content dimensions (`contentHeightPx`, `contentWidthPx`,
`canvasPx`) to both `assets/data/wardrobe.json` and the `WARDROBE` object
in `script.js`, following the same pattern as the existing entries — this
is what keeps the automatic size normalization accurate for the new piece.
